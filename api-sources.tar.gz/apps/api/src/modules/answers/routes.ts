// apps/api/src/modules/answers/routes.ts
import { Router } from "express";
import { AppDataSource } from "../../db/data-source";
import { Answer } from "../../db/entities/Answer";
import { RoundSong } from "../../db/entities/RoundSong";
import { Team } from "../../db/entities/Team";
import { Player } from "../../db/entities/Player";
import { requirePlayer, AuthedPlayer } from "../../middlewares/auth";
import { matchingService } from "../../services/matching.service";
import { answerRateLimit } from "../../middlewares/rate-limit";
import { requireSongOpen, requireStrictTimeWindow, TemporalRequest } from "../../middlewares/temporal-security";

const router = Router();

// HTTP fallback: POST /api/songs/:songId/answers (capitaine uniquement)
router.post(
  "/songs/:songId/answers",
  requirePlayer,
  answerRateLimit,
  requireSongOpen,
  requireStrictTimeWindow,
  async (req: AuthedPlayer & TemporalRequest, res) => {
    const { text } = req.body ?? {};
    if (!text) {
      return res.status(400).json({
        error: { code: "BAD_REQUEST", message: "text required" }
      });
    }

    const teamRepo = AppDataSource.getRepository(Team);
    const playerRepo = AppDataSource.getRepository(Player);
    const ansRepo = AppDataSource.getRepository(Answer);

    // La chanson est déjà validée par les middlewares
    const song = req.song!;
    const now = new Date();

    const team = await teamRepo.findOne({
      where: { id: String(req.player!.teamId) },
      relations: ['captain']
    });
    if (!team) {
      return res.status(404).json({ error: { code: "TEAM_NOT_FOUND" } });
    }

    // Vérifier que le joueur est capitaine
    const player = await playerRepo.findOne({
      where: { id: String(req.player!.playerId) }
    });

    console.log(`[DEBUG] Answer submission attempt:`, {
      playerId: req.player!.playerId,
      teamId: team.id,
      playerFound: !!player,
      isCaptain: player?.is_captain,
      teamCaptainId: team.captain_player_id
    });

    if (!player || !player.is_captain || team.captain_player_id !== player.id) {
      console.log(`[ERROR] Captain check failed - rejecting with 403`);
      return res.status(403).json({
        error: {
          code: "CAPTAIN_ONLY",
          message: "Only the team captain can submit answers",
          debug: {
            playerId: req.player!.playerId,
            playerFound: !!player,
            isCaptain: player?.is_captain,
            teamCaptainId: team.captain_player_id
          }
        }
      });
    }

    // Matching intelligent avec Levenshtein et alias
    const matchResult = await matchingService.scoreAnswer(text, song.id);

    // Upsert dernière réponse (unique par (song, team))
    let answer = await ansRepo.findOne({
      where: { round_song_id: song.id, team_id: team.id },
    });
    if (!answer) {
      answer = new Answer();
      answer.round_song_id = song.id;
      answer.team_id = team.id;
      answer.tenant_id = team.tenant_id; // Hériter le tenant_id de l'équipe
    }
    answer.text_raw = text;
    answer.text_norm = matchResult.normalizedAnswer;
    answer.submitted_at = now; // horloge serveur
    answer.match_title = matchResult.matchTitle;
    answer.match_artist = matchResult.matchArtist;
    answer.points = matchResult.points;

    const saved = await ansRepo.save(answer);
    return res.json({
      songId: song.id,
      teamId: team.id,
      accepted: true,
      submittedAt: saved.submitted_at.toISOString(),
      points: saved.points,
      matchTitle: saved.match_title,
      matchArtist: saved.match_artist
    });
  },
);

export default router;
